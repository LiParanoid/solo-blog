title: spring注解学习（一）项目初始化以及自定义bean的注册
date: '2019-12-01 01:03:30'
updated: '2019-12-01 01:03:30'
tags: [Spring, Springannotation]
permalink: /articles/2019/12/01/1575133409963.html
---
# Spring 注解学习（一）

Spring 中最重要的是 IoC 和 DI，即控制反转和依赖注入，所有的组件都应该放入 Spring 的 IoC 容器中，组件之间的关系通过容器自动装配，也就是我们所说的依赖注入，接下来看通过纯注解的方式来完成组件的注册、管理、依赖、管理功能。首先来创建一个 Maven 工程。

![image.png](https://img.hacpai.com/file/2019/11/image-2bf9fa54.png)

引入 Spring 相关依赖

```xml
<!-- https://mvnrepository.com/artifact/org.springframework/spring-context -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>5.2.1.RELEASE</version>
</dependency>

```

会为我们导入这些包：

![image.png](https://img.hacpai.com/file/2019/11/image-384a1d4b.png)

这里我还额外引入了一个**lombok**依赖，方便我编写 bean 类

```
<!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.18.10</version>
            <scope>provided</scope>
        </dependency>
```

接下来我们创建一个 bean

![image.png](https://img.hacpai.com/file/2019/12/image-0b17efc6.png)


然后我们如果想要在 Spring 中使用这个 bean 的话，就可以用 XML 的配置方式以及注解方式。首先来看之前的 XML 的配置方式

首先在**resource**目录下新建**bean.xml**文件，IDEA 的话这样创建 Spring 的配置文件

![image.png](https://img.hacpai.com/file/2019/12/image-17d252bf.png)

添加bean标签，将Person类进行注册，并且根据 **id=person** 从spring容器中获取

`<bean id="person" class="com.paranoid.bean.Person"></bean>`

可以在bean中添加property来进行初始化
````
<property name="name" value="xiaoming"></property>
<property name="age" value="18"></property>
````

接下来写一个主测试类测试一下

![image.png](https://img.hacpai.com/file/2019/12/image-0d48273e.png)

由于我们是通过xml配置文件方式将bean进行注册 所以我们获取spring容器的方法为通过类路径下的xml配置文件，会返回一个IOC容器对象

````
ApplicationContext applicationContext = new ClassPathXmlApplicationContext("bean.xml");
//这里可通过id的value获取，也可通过Person.class获取
//Person person = applicationContext.getBean(Person.class);
Person person = (Person) applicationContext.getBean("person");
````
接下来看输出效果：

![image.png](https://img.hacpai.com/file/2019/12/image-ddd7b85b.png)

这样我们就成功通过bean配置文件获取到了容器中的bean。

接下来通过注解的方式开发，不编写xml的话，我们可以编写一个称之为配置类的文件

![image.png](https://img.hacpai.com/file/2019/12/image-3284c8f0.png)

最后编写配置类的内容：
```
package com.paranoid.config;

/**
 * @author Paranoid
 * @create 2019-12-01 0:27
 */

        import com.paranoid.bean.Person;
        import org.springframework.context.annotation.Bean;
        import org.springframework.context.annotation.Configuration;

/**
 * 配置类就相当于我们以前的配置文件
 */
//@Configuration 这个注解就告诉Spring这是一个配置类
@Configuration
public class MainConfig {
    /**
     * 接下来进行bean的注册，我们可以写一个方法
     * 将这个方法加上@Bean注解，表示为spring注册一个bean 和配置文件中bean标签作用一致
     * 类型为返回值类型，id为方法名（也可通过 @Bean(value="personXXX") 指定id）
     * @return
     */
    @Bean
    public Person person(){
        return new Person("xiaoming",19);
    }
}

```
配置类编写完成后如何使用呢？其实和xml方式大同小异，只不过换了一个创建的方式

```
ApplicationContext applicationContext = new AnnotationConfigApplicationContext(MainConfig.class);
Person person = (Person) applicationContext.getBean(Person.class);
```
我们可以这样获取现在spring容器中的bean的id，根据类型获取
```
String[] beanNamesForType = applicationContext.getBeanNamesForType(Person.class);
        for (String beanName : beanNamesForType) {
            System.out.println(beanName);
        }
```
可以看到打印出了我们在MainConfig中定义的方法名，此时如果修改@Bean的value值
`@Bean("person01")`
再次进行打印，则能看到输出我们修改后的方法名，也就是说我们是可以进行自定义的。

代码地址：https://github.com/LiParanoid/spring-annotation.git
