title: 我在 GitHub 上的开源项目
date: '2019-11-25 13:38:31'
updated: '2019-11-25 13:38:31'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [ParanoidPoem_Java](https://github.com/LiParanoid/ParanoidPoem_Java) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/LiParanoid/ParanoidPoem_Java/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/LiParanoid/ParanoidPoem_Java/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/LiParanoid/ParanoidPoem_Java/network/members "分叉数")</span>

诗词项目后端



---

### 2. [ParanoidPoem_Vue](https://github.com/LiParanoid/ParanoidPoem_Vue) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/LiParanoid/ParanoidPoem_Vue/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/LiParanoid/ParanoidPoem_Vue/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/LiParanoid/ParanoidPoem_Vue/network/members "分叉数")</span>

诗词项目的Vue代码



---

### 3. [LiParanoid.github.io](https://github.com/LiParanoid/LiParanoid.github.io) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/LiParanoid/LiParanoid.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/LiParanoid/LiParanoid.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/LiParanoid/LiParanoid.github.io/network/members "分叉数")</span>





---

### 4. [ParanoidMusic_Vue](https://github.com/LiParanoid/ParanoidMusic_Vue) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/LiParanoid/ParanoidMusic_Vue/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/LiParanoid/ParanoidMusic_Vue/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/LiParanoid/ParanoidMusic_Vue/network/members "分叉数")</span>

自己音乐网站的Vue



---

### 5. [crud_ssm](https://github.com/LiParanoid/crud_ssm) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/LiParanoid/crud_ssm/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/LiParanoid/crud_ssm/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/LiParanoid/crud_ssm/network/members "分叉数")</span>





---

### 6. [SpringBoot-SSM](https://github.com/LiParanoid/SpringBoot-SSM) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/LiParanoid/SpringBoot-SSM/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/LiParanoid/SpringBoot-SSM/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/LiParanoid/SpringBoot-SSM/network/members "分叉数")</span>



