title: SpringBoot学习（一）一个简单的SpringBoot 应用
date: '2019-12-03 11:03:34'
updated: '2019-12-03 11:18:46'
tags: [SpringBoot]
permalink: /articles/2019/12/03/1575342214500.html
---
![](https://img.hacpai.com/bing/20180702.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1.首先来创建一个简单的 SpringBoot 应用，首先新建一个 Maven 工程

![image.png](https://img.hacpai.com/file/2019/12/image-39b4d34a.png)

![image.png](https://img.hacpai.com/file/2019/12/image-04b8c4c0.png)

![image.png](https://img.hacpai.com/file/2019/12/image-ad3d607f.png)

## 2.接下来导入 SpringBoot 相关的依赖

![image.png](https://img.hacpai.com/file/2019/12/image-f6332ee5.png)

在这里可以看到官网的样例，以及我们需要一个 Web 项目 所以我们添加父依赖后，还要添加 Web 模块依赖，在 pom.xml 的文件中添加如下内容：

```
<parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.2.1.RELEASE</version>
    </parent>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
    </dependencies>
```

## 3.编写一个主程序，这个主程序作用是启动 SpringBoot 应用

在`/main/java`目录下新建一个主程序类，还需要将这个主程序放在我们定义的某一个包下，所以我们新建类时应该这样：
点击`/main/java`，右键新建 `Java Class`
![image.png](https://img.hacpai.com/file/2019/12/image-8ac47784.png)

类名前加上包名，IDEA 会为我们创建目录结构

主程序有了之后，我们还得告诉 SpringBoot，我们新建的这个类是一个启动类，所以我们需要一个注解：`@SpringBootApplication`，接下来我们在这个类中写一个`main`方法，内容如下：

```
public static void main(String[] args) {
    SpringApplication.run(HelloWorldMainApplication.class, args);
  }
```

Spring 应用跑起来的意思，并且需要传入主程序类，以及运行可变参数

## 4.编写对应的 Controller，Service

在`com.paranoid`右键新建`Java Class`，命名还和之前一样`包名.类型`，以后不再赘述。
新建`HelloController`,内容如下:

```
/**
 * @author Paranoid
 * @create 2019-12-03 10:42
 */

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @Controller: HelloController能够处理请求应标注@Controller注解
 */
@Controller
public class HelloController {

    /**
     * @RequestMapping("/hello"): 表示 hello()方法处理的是/hello请求，并返回“Hello”给浏览器，
     *                             但是如果想返回给浏览器，还需要@ResponseBody
     */
    @ResponseBody
    @RequestMapping("/hello")
    public String hello(){
        return "Hello";
    }
}

```

## 5.运行测试

接下来我们想要看一下效果，就去启动主程序类中的`main`方法

> Tomcat started on port(s): 8080 (http) with context path ''
> Started HelloWorldMainApplication in 1.825 seconds (JVM running for 3.23)

可以看到 Tomcat 已经在 8080 端口启动，现在去访问它:

> http://localhost:8080/hello

能看到返回的 Hello 值

## 6.部署

还是在刚才的**SpringBoot 官网**，可以看到 pom.xml 中有：

```
<build>
    <plugins>
        <plugin>
             <groupId>org.springframework.boot</groupId>
             <artifactId>spring-boot-maven-plugin</artifactId>
        </plugin>
    </plugins>
</build>
```

这个依赖就是可以将应用打包成可执行 jar 包，将其添加到我们项目的 pom 文件中。
然后点击侧边栏 Maven 中的 Lifecycle 中的 package：
![image.png](https://img.hacpai.com/file/2019/12/image-fd93460c.png)

> Building jar: D:\IdeaProjects\spring-boot-01-helloworld\target\spring-boot-01-helloworld-1.0-SNAPSHOT.jar

控制台中会输出打包后的 jar 包的位置，找到这个 jar 包复制出来，然后调出 cmd 窗口，保证你配置了 Java 环境变量，然后执行：

> D:\IdeaProjects&gt;java -jar spring-boot-01-helloworld-1.0-SNAPSHOT.jar

可以看到我们也将项目启动起来了，并且没有依赖外部的 Tomcat 容器。

**总结**：这样一个简单的SpringBoot应用的搭建编写部署就完成了

**代码地址**：https://github.com/LiParanoid/SpringBootStudy
