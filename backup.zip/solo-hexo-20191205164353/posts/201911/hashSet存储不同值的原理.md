title: hashSet存储不同值的原理
date: '2019-11-26 14:46:17'
updated: '2019-11-26 14:46:17'
tags: [HashSet]
permalink: /articles/2019/11/26/1574750777504.html
---
# hashSet存储不同值的原理
**hash函数**

* 把任意长度的输入（又叫做预映射pre-image）通过散列算法变换成固定长度的输出，该输出就是散列值，是一种压缩映射。
    
* 或者说一种将任意长度的消息压缩到某一固定长度的消息摘要的函数。
    

**HashCode**

* HashCode是Object的一个方法，hashCode方法返回一个hash code值，且这个方法是为了更好的支持hash表，比如String，Set，HashTable、HashMap等;
    

我们知道hashset是一个单列，无序的，不能重复的集合，同时它的数据结构是数组+链表/红黑树

进入正题：hashset存储不同值的原理？

在hashset中存储值，他会用hashcode和equals方法来确定元素是否存在。

它的过程：

首先他会判断该对象的hash值在hashset集合中是否存在（自定义对象要自己实现hashcode方法和equals方法，String等已经实现不需要自己再实现），如果不存在则存入集合（这个时候就用到它的数据结构了，数组！！！其实存入的就是数组），如果存在相同的hash值，则判断equals方法，相同就不存，如果不同，则证明，该集合中存在与该对象相同的hash值但是值不同的对象，就会再判断它是否有树结点，有就转换为红黑树，否则，就存入链表，如果链表值大于8就会转换为红黑树，下边是它的流程图。
![null](https://img2018.cnblogs.com/blog/1483597/201907/1483597-20190706101136393-1096775863.png)
![null](https://img2018.cnblogs.com/blog/1483597/201907/1483597-20190706101155003-1906543886.png)
