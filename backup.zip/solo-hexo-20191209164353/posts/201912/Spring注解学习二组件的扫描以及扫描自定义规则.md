title: Spring注解学习（二）组件的扫描以及扫描自定义规则
date: '2019-12-01 22:52:55'
updated: '2019-12-03 11:04:06'
tags: [Spring, Springannotation]
permalink: /articles/2019/12/01/1575211974965.html
---
![](https://img.hacpai.com/bing/20180330.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# spring注解学习（二）组件的扫描以及扫描自定义规则
上一篇讲到了通过注解方式向容器中加载组件，那么当我们有很多组件时，如果全部扫描进去呢？
xml配置文件的方式为：
在xml配置文件中添加
```
<!-- 扫描指定包下的 @Controller @Service @Repository @Component 注解的类-->
<context:component-scan base-package="com.paranoid" />
```
这样的话 我们就先新建几个标注了对应注解的类

![image.png](https://img.hacpai.com/file/2019/12/image-75594c9a.png)

为其加上 @Controller @Service @Repository 注解

```
<dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
        </dependency>
```
引入junit，写一个测试类
```
@Test
    public void testXmlComponentScan(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("bean.xml");
        String[] names = applicationContext.getBeanDefinitionNames();
        for (String name : names) {
            System.out.println(name);
        }
    }
```
输出的结果为：
> mainConfig
bookController
bookDao
bookService
org.springframework.context.annotation.internalConfigurationAnnotationProcessor
org.springframework.context.annotation.internalAutowiredAnnotationProcessor
org.springframework.context.annotation.internalCommonAnnotationProcessor
org.springframework.context.event.internalEventListenerProcessor
org.springframework.context.event.internalEventListenerFactory
person01

也就是说xml通过这样就将我们标注了对应注解的类进行了注入

接下来通过注解的方式完成相同的功能，在MainConfig中添加
`@ComponentScan(value = "com.paranoid")`
再次在测试类中进行测试
```
@Test
    public void testAnnotationComponentScan(){
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(MainConfig.class);
        String[] names = applicationContext.getBeanDefinitionNames();
        for (String name : names) {
            System.out.println(name);
        }
    }
```
输出结果为
> org.springframework.context.annotation.internalConfigurationAnnotationProcessor
org.springframework.context.annotation.internalAutowiredAnnotationProcessor
org.springframework.context.annotation.internalCommonAnnotationProcessor
org.springframework.context.event.internalEventListenerProcessor
org.springframework.context.event.internalEventListenerFactory
mainConfig
bookController
bookDao
bookService
person01

这样就通过注解的方式扫描到了指定包下的所有被上述注解标注的类，注册进IOC容器中。
还可以进行扫描规则的限定
`@ComponentScan(value = "com.paranoid" ,excludeFilters = {@ComponentScan.Filter(type = FilterType.ANNOTATION,classes = Controller.class)})`
**excludeFilters**指的是排除哪些，这样就排除了Controller注解所修饰的类
输出结果如下
> org.springframework.context.annotation.internalConfigurationAnnotationProcessor
org.springframework.context.annotation.internalAutowiredAnnotationProcessor
org.springframework.context.annotation.internalCommonAnnotationProcessor
org.springframework.context.event.internalEventListenerProcessor
org.springframework.context.event.internalEventListenerFactory
mainConfig
bookDao
bookService
person01

同理**includeFilters**指的是只扫描哪些，这样就只扫描了Controller注解所修饰的类，同时，这种情况下要将**useDefaultFilters = false**此项进行设置
`@ComponentScan(value = "com.paranoid" ,useDefaultFilters = false,includeFilters = {@ComponentScan.Filter(type = FilterType.ANNOTATION,classes = Controller.class)})`
输出结果为：
org.springframework.context.annotation.internalConfigurationAnnotationProcessor
org.springframework.context.annotation.internalAutowiredAnnotationProcessor
org.springframework.context.annotation.internalCommonAnnotationProcessor
org.springframework.context.event.internalEventListenerProcessor
org.springframework.context.event.internalEventListenerFactory
mainConfig
bookController
person01

代码地址：[https://github.com/LiParanoid/spring-annotation.git](https://github.com/LiParanoid/spring-annotation.git)
